# Contributing

Thanks for helping improve Alice Cyber Community Edition.

## Contribution rules

Accepted:

- safer parsers for already-collected evidence
- better report formatting
- clearer remediation guidance
- tests that strengthen safety boundaries
- documentation improvements

Not accepted:

- live scanners
- exploit execution
- credential collection
- stealth/evasion
- log deletion
- hack-back features
- code that bypasses authorization or path safety

## Development

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .[dev]
pytest
```
