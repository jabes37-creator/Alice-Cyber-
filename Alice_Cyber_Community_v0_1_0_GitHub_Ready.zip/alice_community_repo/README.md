# Alice Cyber Community Edition

**Alice Cyber Community Edition** is the open-source, evidence-first version of Alice Cyber.

It is designed for one safe workflow:

> **Evidence in → prioritized security report out.**

Alice Community parses security evidence you already collected, identifies review items, and generates human-readable reports. It does **not** run live scans, execute exploits, access credentials, delete logs, hide activity, move laterally, or attack anyone.

## Why this exists

The full Alice Cyber project is becoming a governed defensive cybersecurity product. This Community Edition is the safe public wedge: useful enough to help people, simple enough to audit, and limited enough to avoid dangerous autonomous behavior.

## What it can do

- Parse supplied evidence from Nmap text/XML, Nessus/OpenVAS-style CSV, and Nuclei JSONL.
- Generate Markdown, JSON, or simple HTML reports.
- Create an evidence-review workspace for small client assessments.
- Enforce hard safety boundaries against live offensive requests.
- Refuse sensitive local paths such as `.ssh`, browser cookies, keychains, tokens, and system log folders.

## What it intentionally cannot do

- No live scanning.
- No autonomous command execution.
- No exploit execution.
- No credential access.
- No lateral movement.
- No log deletion or anti-forensics.
- No hack-back or retaliation.
- No claims that a system is secure without human review.

## Install from source

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -e .
```

## Usage

Create a client evidence workspace:

```bash
alice-community --create-workspace ./demo_client --client-name "Demo Client"
```

Analyze Nmap evidence:

```bash
alice-community --file data/sample_nmap.txt --scanner nmap --client-name "Demo Client" --out report.md
```

Analyze inline evidence:

```bash
alice-community --text "Nmap scan report for 10.0.0.5
80/tcp open http" --scanner nmap
```

## Community vs commercial boundary

This repository is the open-source community toolkit. It is not the full enterprise product. Commercial/private layers may include customer portals, tenant isolation, enterprise policy gates, signed update workflows, case databases, and managed service packaging.

## Responsible use

Use Alice Community only on evidence you are authorized to review. Do not use it to plan unauthorized testing, evade detection, access credentials, or retaliate against third parties.

## License

MIT License. See `LICENSE`.
