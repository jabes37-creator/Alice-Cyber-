# Code of Conduct

Be respectful, constructive, and safety-minded. This project is for defensive cybersecurity education and evidence review. Do not use issues, pull requests, or discussions to request unauthorized hacking, evasion, credential theft, or retaliation.
