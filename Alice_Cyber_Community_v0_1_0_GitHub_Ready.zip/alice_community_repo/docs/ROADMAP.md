# Roadmap

## v0.1

- Evidence parsers
- Report generator
- Workspace generator
- Hard safety boundaries
- Path safety

## Near-term

- SARIF import/export
- Better dependency scan parsing
- More sample evidence files
- Better severity explanations
- Optional static site report template

## Not planned

- Autonomous scanning
- Exploit execution
- Credential access
- Hack-back features
