# GitHub Publish Commands

Use these after creating an empty GitHub repository named `alice-cyber-community`.

```bash
cd alice-cyber-community
git init
git add .
git commit -m "Initial Alice Cyber Community Edition release"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/alice-cyber-community.git
git push -u origin main
```

Recommended GitHub repo description:

> Open-source evidence-in/report-out defensive cybersecurity review toolkit. No live scanning, exploitation, credential access, or hack-back.

Recommended topics:

```text
cybersecurity defensive-security evidence-review scanner-parser security-reporting nmap nessus nuclei python
```

Suggested first release tag:

```bash
git tag v0.1.0
git push origin v0.1.0
```
