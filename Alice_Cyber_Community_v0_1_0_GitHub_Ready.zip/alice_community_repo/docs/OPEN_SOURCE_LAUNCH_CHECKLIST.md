# Open Source Launch Checklist

Before publishing to GitHub:

- [ ] Create a new public repository named `alice-cyber-community`.
- [ ] Upload this repo package.
- [ ] Confirm README install commands work.
- [ ] Confirm `pytest` passes.
- [ ] Add repository topics: cybersecurity, defensive-security, evidence-review, scanner-parser, security-reporting.
- [ ] Enable Dependabot.
- [ ] Protect `main` branch after the first push.
- [ ] Add a short release `v0.1.0`.
- [ ] Pin a discussion explaining that this is evidence-only and safe-by-design.
