# Community vs Commercial Boundary

Alice Cyber Community Edition is intentionally narrow and open source.

Community Edition includes:

- scanner/evidence parsing
- safe path handling
- hard safety boundaries
- Markdown/JSON/HTML report generation
- evidence-review workspace scaffolding

The commercial/private Alice Cyber product may include:

- enterprise tenant/workspace isolation
- customer trust center
- local API/dashboard
- case/project database
- RBAC and approval gates
- managed service workflows
- signed updates and deployment readiness

This separation keeps the open-source project safe and useful while protecting the larger product roadmap.
