# Security Policy

Alice Cyber Community Edition is intentionally evidence-only.

## Supported safety boundary

This project should never add:

- live scanning or exploitation
- autonomous command execution
- credential/token/keychain/browser-cookie access
- log deletion or anti-forensics
- lateral movement
- hack-back or retaliation
- unauthorized testing workflows

## Reporting a vulnerability

Please open a private security advisory or contact the maintainer with:

- affected version
- affected file/function
- proof of concept, if safe
- expected vs actual behavior
- recommended fix, if known

Do not include real customer secrets, credentials, or private evidence.
