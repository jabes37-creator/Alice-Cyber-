"""Command line interface for Alice Cyber Community Edition."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

from . import __version__
from .core.analyzer import analyze_evidence
from .core.path_security import read_text, write_text, SafePathError
from .core.workspace import create_workspace


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Alice Cyber Community Edition: evidence-in, report-out security review")
    parser.add_argument("--version", action="store_true", help="Print version and exit")
    parser.add_argument("--file", help="Evidence file to parse. No live scanning is performed.")
    parser.add_argument("--text", help="Evidence text to parse")
    parser.add_argument("--scanner", default="auto", choices=["auto", "nmap", "nmap_xml", "nessus", "openvas", "nuclei"], help="Evidence format")
    parser.add_argument("--client-name", default="Client", help="Client/report name")
    parser.add_argument("--scope", default="Evidence supplied by client", help="Written scope statement")
    parser.add_argument("--out", default="", help="Output report path (.md, .json, or .html)")
    parser.add_argument("--create-workspace", default="", help="Create an evidence-review workspace at this path")
    args = parser.parse_args(argv)

    if args.version:
        print(__version__)
        return 0

    try:
        if args.create_workspace:
            root = create_workspace(args.create_workspace, client_name=args.client_name)
            print(f"Created workspace: {root}")
            return 0

        text = args.text or ""
        if args.file:
            text = read_text(args.file)
        if not text:
            text = sys.stdin.read()
        if not text.strip():
            parser.error("Provide --file, --text, or stdin evidence")

        result = analyze_evidence(text, scanner=args.scanner, client_name=args.client_name, scope=args.scope)
        output = result.markdown
        if args.out:
            suffix = Path(args.out).suffix.lower()
            if suffix == ".json":
                output = result.json_report
            elif suffix in {".html", ".htm"}:
                output = result.html_report
            write_text(args.out, output)
            print(f"Wrote report: {Path(args.out).resolve(strict=False)}")
        else:
            print(output)
        return 0 if result.allowed else 2
    except SafePathError as exc:
        print(f"Path refused: {exc}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
