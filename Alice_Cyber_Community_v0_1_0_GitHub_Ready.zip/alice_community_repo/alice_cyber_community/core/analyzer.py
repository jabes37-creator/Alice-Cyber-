"""High-level analysis API."""
from __future__ import annotations

from dataclasses import dataclass
import json

from .safety import check_hard_boundaries
from .parsers import parse_evidence
from .report import render_markdown, render_json, render_html


@dataclass
class AnalysisResult:
    allowed: bool
    findings: list[dict]
    markdown: str
    json_report: str
    html_report: str
    safety_message: str = ""


def analyze_evidence(text: str, *, scanner: str = "auto", client_name: str = "Client", scope: str = "Evidence supplied by client") -> AnalysisResult:
    safety = check_hard_boundaries(" ".join([text[:2000], scanner, scope]))
    if not safety.allowed:
        return AnalysisResult(
            allowed=False,
            findings=[],
            markdown=f"# Request Blocked\n\n{safety.message}\n\nIssue: `{safety.issue}`\n",
            json_report=json.dumps({"allowed": False, "issue": safety.issue, "message": safety.message}) + "\n",
            html_report="<!doctype html><html><body><h1>Request Blocked</h1></body></html>\n",
            safety_message=safety.message,
        )
    findings = parse_evidence(text, scanner=scanner)
    return AnalysisResult(
        allowed=True,
        findings=findings,
        markdown=render_markdown(findings, client_name=client_name, scope=scope),
        json_report=render_json(findings, client_name=client_name, scope=scope),
        html_report=render_html(findings, client_name=client_name, scope=scope),
    )
