"""Non-overridable safety boundaries for the Community Edition.

This open-source edition is evidence-in/report-out only. It intentionally has no live scanning,
no shell execution, no exploit runner, and no credential access.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable
import re


@dataclass(frozen=True)
class SafetyResult:
    allowed: bool
    issue: str = ""
    message: str = ""


HARD_BOUNDARIES: dict[str, tuple[str, ...]] = {
    "autonomous_command_execution": (
        "run commands autonomously", "execute shell", "subprocess", "run nmap", "execute payload",
        "run exploit", "shell command", "cmd.exe", "powershell -enc", "bash -c",
    ),
    "credential_access": (
        "steal password", "dump credentials", "access credentials", "read tokens", "browser cookies",
        "keychain", ".ssh", "id_rsa", "private key", "session cookie", "api token",
    ),
    "anti_forensics": (
        "delete logs", "wipe logs", "erase logs", "cover tracks", "hide activity", "clear event logs",
        "remove audit", "disable logging",
    ),
    "lateral_movement": (
        "move laterally", "pivot", "pass the hash", "psexec", "remote shell", "spread to",
    ),
    "hack_back": (
        "hack back", "attack scammer", "retaliate", "ddos", "take down", "destroy their server",
    ),
    "unauthorized_live_scanning": (
        "scan the internet", "scan public ips", "scan without permission", "masscan", "live scan",
    ),
}


def _normalize(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").lower()).strip()


def check_hard_boundaries(text: str, extra_terms: Iterable[str] | None = None) -> SafetyResult:
    """Return a deny decision if text asks for blocked behavior.

    This is intentionally conservative. Safe defensive alternatives should happen outside this
    function, after the request is confirmed to be inside the evidence-only scope.
    """
    haystack = _normalize(text)
    if extra_terms:
        haystack += " " + _normalize(" ".join(extra_terms))
    for issue, phrases in HARD_BOUNDARIES.items():
        for phrase in phrases:
            if _normalize(phrase) in haystack:
                return SafetyResult(
                    allowed=False,
                    issue=issue,
                    message=(
                        "Blocked by Alice Cyber Community hard boundary. This edition supports "
                        "evidence review and report generation only, not live offensive actions."
                    ),
                )
    return SafetyResult(allowed=True)
