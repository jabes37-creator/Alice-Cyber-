"""Simple severity scoring for evidence-only findings."""
from __future__ import annotations

SEVERITY_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}

KEYWORD_RULES: list[tuple[str, str, str]] = [
    ("critical", "rce", "Potential remote code execution evidence"),
    ("critical", "remote code execution", "Potential remote code execution evidence"),
    ("high", "default password", "Default credential exposure indicator"),
    ("high", "anonymous ftp", "Anonymous FTP exposure"),
    ("high", "admin panel", "Administrative interface exposure"),
    ("high", "0.0.0.0/0", "Overly broad network exposure"),
    ("high", "secret", "Potential secret exposure"),
    ("medium", "tlsv1", "Legacy TLS protocol indicator"),
    ("medium", "ssl", "SSL/TLS configuration should be reviewed"),
    ("medium", "x-frame-options", "Missing or weak browser security header"),
    ("medium", "cve-", "Known vulnerability reference found"),
    ("low", "open port", "Open service should be validated against business need"),
    ("low", "http", "Plain HTTP or web service exposure should be reviewed"),
]


def infer_severity(text: str) -> tuple[str, str]:
    lowered = (text or "").lower()
    for severity, needle, reason in KEYWORD_RULES:
        if needle in lowered:
            return severity, reason
    return "info", "Evidence item noted for human review"


def sort_findings(findings: list[dict]) -> list[dict]:
    return sorted(findings, key=lambda item: SEVERITY_ORDER.get(item.get("severity", "info"), 0), reverse=True)
