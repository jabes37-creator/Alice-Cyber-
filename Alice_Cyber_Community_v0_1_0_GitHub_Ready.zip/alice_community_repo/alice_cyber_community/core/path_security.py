"""Safe local path helpers.

The Community Edition may read user-supplied evidence files and write reports, but it refuses
sensitive locations such as SSH keys, browser cookies, keychains, system folders, and hidden
credential directories.
"""
from __future__ import annotations

from pathlib import Path


class SafePathError(ValueError):
    """Raised when a path is not safe for Alice Community to read or write."""


SENSITIVE_PARTS = {
    ".ssh", ".gnupg", ".aws", ".azure", ".kube", "keychains", "keychain", "cookies",
    "login data", "credentials", "secrets", "tokens",
}
SENSITIVE_NAMES = {
    "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519", "known_hosts", "authorized_keys",
    "login.keychain-db", "cookies.sqlite", "login data",
}
BLOCKED_ROOTS = {"/etc", "/var/log", "/root", "/private/etc"}


def _path_words(path: Path) -> list[str]:
    return [part.lower() for part in path.parts]


def validate_path(path: str | Path, *, must_exist: bool = False, for_write: bool = False) -> Path:
    candidate = Path(path).expanduser()
    if must_exist and not candidate.exists():
        raise SafePathError(f"Path does not exist: {candidate}")
    resolved = candidate.resolve(strict=False)
    words = _path_words(resolved)
    as_posix = resolved.as_posix().lower()
    if any(part in SENSITIVE_PARTS for part in words):
        raise SafePathError(f"Refusing sensitive path: {resolved}")
    if resolved.name.lower() in SENSITIVE_NAMES:
        raise SafePathError(f"Refusing sensitive file: {resolved}")
    if any(as_posix == root or as_posix.startswith(root + "/") for root in BLOCKED_ROOTS):
        raise SafePathError(f"Refusing system path: {resolved}")
    if for_write:
        parent = resolved.parent
        if parent.exists() and not parent.is_dir():
            raise SafePathError(f"Output parent is not a directory: {parent}")
    return resolved


def read_text(path: str | Path, *, max_bytes: int = 2_000_000) -> str:
    safe = validate_path(path, must_exist=True)
    if safe.is_dir():
        raise SafePathError(f"Refusing to read directory as file: {safe}")
    data = safe.read_bytes()
    if len(data) > max_bytes:
        raise SafePathError(f"Evidence file is too large for Community Edition: {safe}")
    return data.decode("utf-8", errors="replace")


def write_text(path: str | Path, content: str) -> Path:
    safe = validate_path(path, for_write=True)
    safe.parent.mkdir(parents=True, exist_ok=True)
    safe.write_text(content, encoding="utf-8")
    return safe
