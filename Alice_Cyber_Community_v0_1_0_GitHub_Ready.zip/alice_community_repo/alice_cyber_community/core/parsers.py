"""Evidence parsers for scanner/export files Alice Community can safely analyze.

These parsers do not scan. They only parse evidence the user already collected.
"""
from __future__ import annotations

import csv
import io
import json
import re
from xml.etree import ElementTree as ET

from .scoring import infer_severity, sort_findings


def parse_nmap_text(text: str) -> list[dict]:
    findings: list[dict] = []
    host = "unknown"
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        host_match = re.search(r"Nmap scan report for\s+(.+)$", line, re.I)
        if host_match:
            host = host_match.group(1).strip()
            continue
        port_match = re.match(r"(\d+)/(tcp|udp)\s+open\s+(\S+)(?:\s+(.*))?$", line, re.I)
        if port_match:
            port, proto, service, details = port_match.groups()
            evidence = f"Open port {port}/{proto} {service} {details or ''}".strip()
            severity, reason = infer_severity(evidence)
            findings.append({
                "title": f"Open service: {service} on {host}:{port}/{proto}",
                "severity": severity,
                "asset": host,
                "evidence": evidence,
                "reason": reason,
                "recommendation": "Confirm business need, restrict exposure where possible, and verify patch/configuration status.",
            })
    return sort_findings(findings)


def parse_nmap_xml(text: str) -> list[dict]:
    findings: list[dict] = []
    try:
        root = ET.fromstring(text)
    except ET.ParseError:
        return []
    for host_el in root.findall("host"):
        address = "unknown"
        addr_el = host_el.find("address")
        if addr_el is not None:
            address = addr_el.attrib.get("addr", "unknown")
        for port_el in host_el.findall(".//port"):
            state_el = port_el.find("state")
            if state_el is None or state_el.attrib.get("state") != "open":
                continue
            service_el = port_el.find("service")
            service = service_el.attrib.get("name", "unknown") if service_el is not None else "unknown"
            port_id = port_el.attrib.get("portid", "unknown")
            proto = port_el.attrib.get("protocol", "tcp")
            evidence = f"Open port {port_id}/{proto} {service}"
            severity, reason = infer_severity(evidence)
            findings.append({
                "title": f"Open service: {service} on {address}:{port_id}/{proto}",
                "severity": severity,
                "asset": address,
                "evidence": evidence,
                "reason": reason,
                "recommendation": "Confirm business need, restrict exposure where possible, and verify patch/configuration status.",
            })
    return sort_findings(findings)


def parse_csv_findings(text: str, scanner: str) -> list[dict]:
    findings: list[dict] = []
    reader = csv.DictReader(io.StringIO(text))
    for row in reader:
        row_lower = {str(k).lower().strip(): v for k, v in row.items()}
        title = row_lower.get("name") or row_lower.get("plugin name") or row_lower.get("nvt name") or row_lower.get("title") or "Scanner finding"
        host = row_lower.get("host") or row_lower.get("ip") or row_lower.get("asset") or "unknown"
        raw_sev = (row_lower.get("severity") or row_lower.get("risk") or "").lower()
        if raw_sev in {"critical", "high", "medium", "low", "info"}:
            severity = raw_sev
            reason = f"{scanner} reported severity: {raw_sev}"
        else:
            severity, reason = infer_severity(" ".join(str(v) for v in row_lower.values()))
        evidence = row_lower.get("description") or row_lower.get("summary") or row_lower.get("solution") or str(row)
        findings.append({
            "title": title,
            "severity": severity,
            "asset": host,
            "evidence": evidence[:1200],
            "reason": reason,
            "recommendation": row_lower.get("solution") or "Validate finding, patch or harden affected component, then retest.",
        })
    return sort_findings(findings)


def parse_nuclei_jsonl(text: str) -> list[dict]:
    findings: list[dict] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        info = item.get("info", {}) if isinstance(item.get("info"), dict) else {}
        title = info.get("name") or item.get("template-id") or "Nuclei finding"
        severity = str(info.get("severity") or "info").lower()
        if severity not in {"critical", "high", "medium", "low", "info"}:
            severity, _ = infer_severity(json.dumps(item))
        findings.append({
            "title": title,
            "severity": severity,
            "asset": item.get("host") or item.get("matched-at") or "unknown",
            "evidence": json.dumps(item, ensure_ascii=False)[:1200],
            "reason": "Nuclei template result from supplied evidence",
            "recommendation": "Validate the template result, apply vendor or configuration fix, and retest.",
        })
    return sort_findings(findings)


def parse_evidence(text: str, scanner: str = "auto") -> list[dict]:
    scanner = (scanner or "auto").lower().strip()
    if scanner == "nmap_xml" or text.lstrip().startswith("<?xml") or "<nmaprun" in text[:500].lower():
        result = parse_nmap_xml(text)
        if result:
            return result
    if scanner in {"nmap", "auto"} and "nmap scan report" in text.lower():
        return parse_nmap_text(text)
    if scanner in {"nessus", "openvas"}:
        return parse_csv_findings(text, scanner)
    if scanner == "nuclei" or '"template-id"' in text[:2000] or '"matched-at"' in text[:2000]:
        return parse_nuclei_jsonl(text)
    if "," in text.splitlines()[0] if text.splitlines() else False:
        return parse_csv_findings(text, "csv")
    severity, reason = infer_severity(text)
    return [{
        "title": "Unstructured evidence for review",
        "severity": severity,
        "asset": "unknown",
        "evidence": text[:1200],
        "reason": reason,
        "recommendation": "Review the supplied evidence manually and attach supporting context before delivery.",
    }]
