"""Report generation for Alice Cyber Community Edition."""
from __future__ import annotations

from datetime import datetime, timezone
import json
from html import escape


def _counts(findings: list[dict]) -> dict[str, int]:
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
    for finding in findings:
        sev = finding.get("severity", "info")
        counts[sev] = counts.get(sev, 0) + 1
    return counts


def render_markdown(findings: list[dict], *, client_name: str = "Client", scope: str = "Evidence supplied by client") -> str:
    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    counts = _counts(findings)
    lines = [
        f"# Alice Cyber Community Evidence Review: {client_name}",
        "",
        f"Generated: {generated}",
        "",
        "## Scope",
        scope or "Evidence supplied by client",
        "",
        "## Safety Boundary",
        "This report is based only on supplied evidence. Alice Community does not perform live scanning, exploitation, credential access, lateral movement, log deletion, or hack-back.",
        "",
        "## Executive Summary",
        f"Alice reviewed the supplied evidence and identified {len(findings)} item(s) for human review.",
        f"Severity summary: Critical {counts.get('critical',0)}, High {counts.get('high',0)}, Medium {counts.get('medium',0)}, Low {counts.get('low',0)}, Informational {counts.get('info',0)}.",
        "",
        "## Findings",
    ]
    for index, finding in enumerate(findings, 1):
        lines.extend([
            "",
            f"### {index}. {finding.get('title', 'Finding')}",
            f"- Severity: **{finding.get('severity', 'info').upper()}**",
            f"- Asset: `{finding.get('asset', 'unknown')}`",
            f"- Why it matters: {finding.get('reason', 'Requires review')}",
            f"- Evidence: {finding.get('evidence', '')}",
            f"- Recommendation: {finding.get('recommendation', 'Validate and remediate as appropriate.')}",
            "- Retest: Confirm the issue is no longer present in updated evidence after remediation.",
        ])
    lines.extend([
        "",
        "## Next Steps",
        "1. Confirm each finding against business context.",
        "2. Assign owners and target dates for high-priority items.",
        "3. Apply fixes or compensating controls.",
        "4. Retest with fresh evidence and attach the retest output.",
    ])
    return "\n".join(lines) + "\n"


def render_json(findings: list[dict], *, client_name: str = "Client", scope: str = "Evidence supplied by client") -> str:
    payload = {
        "tool": "Alice Cyber Community Edition",
        "version": "0.1.0",
        "client_name": client_name,
        "scope": scope,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "safety_boundary": "Evidence review only. No live scanning/exploitation/credential access.",
        "summary": _counts(findings),
        "findings": findings,
    }
    return json.dumps(payload, indent=2, ensure_ascii=False) + "\n"


def render_html(findings: list[dict], *, client_name: str = "Client", scope: str = "Evidence supplied by client") -> str:
    md = render_markdown(findings, client_name=client_name, scope=scope)
    body = "\n".join(f"<p>{escape(line)}</p>" if line else "<br>" for line in md.splitlines())
    return f"<!doctype html><html><head><meta charset='utf-8'><title>Alice Evidence Review</title></head><body>{body}</body></html>\n"
