"""GitHub/community-safe workspace generator."""
from __future__ import annotations

from pathlib import Path
from .path_security import write_text, validate_path

WORKSPACE_DIRS = [
    "00_intake", "01_authorization", "02_evidence/raw", "02_evidence/processed",
    "03_analysis", "04_reports/draft", "04_reports/final", "05_retest", "06_exports",
]


def create_workspace(path: str | Path, *, client_name: str = "Client") -> Path:
    root = validate_path(path, for_write=True)
    root.mkdir(parents=True, exist_ok=True)
    for rel in WORKSPACE_DIRS:
        (root / rel).mkdir(parents=True, exist_ok=True)
    write_text(root / "00_intake" / "client_intake.md", f"# Client Intake: {client_name}\n\n- Client:\n- Contact:\n- Scope:\n- Evidence supplied:\n- Constraints:\n")
    write_text(root / "01_authorization" / "authorization_template.md", "# Authorization Template\n\nThis assessment is limited to evidence supplied by the client. No live scanning or testing is performed by Alice Community.\n")
    write_text(root / "05_retest" / "retest_checklist.md", "# Retest Checklist\n\n- Attach updated evidence.\n- Compare against original findings.\n- Mark fixed, partial, not fixed, or risk accepted.\n")
    return root
