"""Core modules for Alice Cyber Community Edition."""
