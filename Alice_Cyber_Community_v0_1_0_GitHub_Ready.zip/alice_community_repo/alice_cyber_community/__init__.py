"""Alice Cyber Community Edition.

A safe, evidence-first cybersecurity reporting toolkit extracted from the Alice Cyber project.
It does not perform live scanning, exploitation, credential access, lateral movement, or autonomous shell execution.
"""

__version__ = "0.1.0"

from .core.analyzer import analyze_evidence

__all__ = ["analyze_evidence", "__version__"]
