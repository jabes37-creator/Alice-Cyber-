from pathlib import Path

from alice_cyber_community.core.analyzer import analyze_evidence
from alice_cyber_community.core.path_security import validate_path, SafePathError
from alice_cyber_community.core.workspace import create_workspace
from alice_cyber_community.cli import main


def test_nmap_report_generation():
    result = analyze_evidence("Nmap scan report for 10.0.0.5\n80/tcp open http", scanner="nmap", client_name="ACME")
    assert result.allowed is True
    assert "Alice Cyber Community Evidence Review: ACME" in result.markdown
    assert "Open service" in result.markdown


def test_hard_boundary_blocks_hack_back():
    result = analyze_evidence("hack back and attack scammer server")
    assert result.allowed is False
    assert "Blocked" in result.markdown


def test_sensitive_path_refused(tmp_path):
    ssh_dir = tmp_path / ".ssh"
    ssh_dir.mkdir()
    secret = ssh_dir / "id_rsa"
    secret.write_text("secret")
    try:
        validate_path(secret, must_exist=True)
    except SafePathError:
        pass
    else:
        raise AssertionError("sensitive path should be refused")


def test_workspace_creation(tmp_path):
    root = create_workspace(tmp_path / "client", client_name="Demo")
    assert (root / "00_intake" / "client_intake.md").exists()
    assert (root / "04_reports" / "final").exists()


def test_cli_version(capsys):
    code = main(["--version"])
    out = capsys.readouterr().out
    assert code == 0
    assert "0.1.0" in out
